<?php
/**
 * Crosslinks
 *
 * Copyright 2018-2022 by Thomas Jakobi <office@treehillstudio.com>
 *
 * @package crosslinks
 * @subpackage classfile
 */

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

/**
 * class Crosslinks
 */
class Crosslinks extends \TreehillStudio\Crosslinks\Crosslinks
{
}
