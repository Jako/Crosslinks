# Crosslinks

Manage and display crosslinks on your site

- Author: Thomas Jakobi <thomas.jakobi@partout.info>
- License: GNU GPLv2

## Features

- Custom Manager Page for maintaining the crosslinks
- Plugin for replacing the linktexts with the crosslinks in a MODX resource

## Installation

MODX Package Management

## Documentation

For more information please read the documentation on https://jako.github.io/Crosslinks/

## GitHub Repository

https://github.com/Jako/Crosslinks
