<?php
/**
 * @package crosslinks
 */
class CrosslinksLink extends xPDOSimpleObject {}
?>